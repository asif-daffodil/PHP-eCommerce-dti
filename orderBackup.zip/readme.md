# E-commerce Project ![PHP and MySQLi](https://badgen.net/badge/PHP/MySQLi/blue)

```sh
database name: evaly
admin email: asif@dti.ac
admin password:  123456
```

#### Technologies:

- HTML
- CSS
- Bootstrap
- JavaScript
- jQuery
- PHP
- Laravel

## Features

- Full Ecommerce system
- Authentication
- Profile updates
- Login/Registration
- Admin Panel
- Product management system
- Orders Management Sytem
- Cart system
- checkout system
