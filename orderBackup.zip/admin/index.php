<?php
include_once("./header.php")
?>
<!-- Main Content -->
<div id="content">
  <?php include_once("./navbar.php") ?>
</div>
<!-- End of Main Content -->

<?php
include_once("./footer.php");
?>