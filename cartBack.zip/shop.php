<?php
include_once("./header.php");
include_once("./navbar.php");
?>
<h1>Shop</h1>

<?php
include_once("./footer.php");
?>